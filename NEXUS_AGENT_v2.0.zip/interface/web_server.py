"""
WEB SERVER — Flask application serving the Nexus Agent GUI Dashboard.
Provides REST API endpoints and real-time updates.
"""
import asyncio, json, time, threading
from datetime import datetime
from flask import Flask, render_template, jsonify, request, send_from_directory
from typing import Optional

class NexusWebServer:
    def __init__(self, config, brain, meta_ai, memory, security, evolution, tools, planner, llm, arbiter, capabilities):
        self.config = config
        self.brain = brain; self.meta_ai = meta_ai; self.memory = memory
        self.security = security; self.evolution = evolution; self.tools = tools
        self.planner = planner; self.llm = llm; self.arbiter = arbiter
        self.capabilities = capabilities
        self.app = Flask(__name__,
            template_folder=str(config.get_path("templates")),
            static_folder=str(config.get_path("static")))
        self.app.config['SECRET_KEY'] = config.secret_key
        self.loop: Optional[asyncio.AbstractEventLoop] = None
        self._register_routes()

    def _run_async(self, coro):
        """Run async code from sync Flask context."""
        # Try submitting to the background loop first
        if self.loop and self.loop.is_running():
            try:
                future = asyncio.run_coroutine_threadsafe(coro, self.loop)
                return future.result(timeout=30)
            except Exception:
                pass
        # Fallback: create a fresh event loop
        try:
            return asyncio.run(coro)
        except RuntimeError:
            # Already inside an event loop — spin up a new one in a thread
            import concurrent.futures
            result = [None]
            exc = [None]
            def _run():
                try:
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    result[0] = loop.run_until_complete(coro)
                    loop.close()
                except Exception as e:
                    exc[0] = e
            t = concurrent.futures.ThreadPoolExecutor(max_workers=1)
            t.submit(_run).result(timeout=30)
            t.shutdown(wait=False)
            if exc[0]:
                raise exc[0]
            return result[0]

    def _register_routes(self):
        app = self.app

        @app.route('/')
        def dashboard():
            return render_template('dashboard.html')

        @app.route('/api/state')
        def api_state():
            """Full agent state snapshot."""
            try:
                brain = self.brain.get_state()
                mem = self.memory.get_stats()
                evo = self.evolution.get_status()
                sec = self.security.get_summary()
                tool = self.tools.get_stats()
                plan = self.planner.get_stats()
                llm = self.llm.get_stats()
                arb = self.arbiter.get_stats()
                try:
                    meta = self._run_async(self.meta_ai.get_report())
                except Exception:
                    meta = {"health": "UNKNOWN", "score": 0, "dimensions": {}, "recommendations": [],
                            "evaluations": 0, "interventions": 0, "active_directives": 0,
                            "total_directives": 0, "meta_confidence": 0}
                return jsonify({
                    "success": True, "timestamp": datetime.now().isoformat(),
                    "brain": brain, "memory": mem, "evolution": evo, "security": sec,
                    "tools": tool, "planning": plan, "llm": llm, "arbiter": arb, "meta_ai": meta
                })
            except Exception as e:
                return jsonify({"success": False, "error": str(e)})

        @app.route('/api/brain')
        def api_brain(): return jsonify(self.brain.get_state())

        @app.route('/api/memory')
        def api_memory(): return jsonify(self.memory.get_stats())

        @app.route('/api/memory/working')
        def api_working_memory():
            entries = [{"id":e.id,"type":e.memory_type,"importance":round(e.importance,3),
                       "content":str(e.content)[:150],"timestamp":e.timestamp}
                      for e in list(self.memory.working_memory.values())[-20:]]
            return jsonify(entries)

        @app.route('/api/evolution')
        def api_evolution(): return jsonify(self.evolution.get_status())

        @app.route('/api/meta')
        def api_meta():
            return jsonify(self._run_async(self.meta_ai.get_report()))

        @app.route('/api/security')
        def api_security(): return jsonify(self.security.get_summary())

        @app.route('/api/security/audit')
        def api_audit(): return jsonify(self.security.get_audit_log(30))

        @app.route('/api/tools')
        def api_tools(): return jsonify(self.tools.get_tools_list())

        @app.route('/api/planning')
        def api_planning(): return jsonify(self.planner.get_stats())

        @app.route('/api/llm')
        def api_llm_status(): return jsonify(self.llm.get_stats())

        @app.route('/api/llm/providers')
        def api_providers(): return jsonify(self.llm.get_providers_info())

        @app.route('/api/llm/configure', methods=['POST'])
        def api_configure_llm():
            data = request.json
            provider = data.get('provider', '')
            api_key = data.get('api_key', '')
            model = data.get('model', '')
            base_url = data.get('base_url', '')
            if not provider:
                return jsonify({"success": False, "error": "Provider required"})
            self.llm.configure(provider, api_key, model, base_url)
            return jsonify({"success": True, "provider": provider, "model": self.config.llm_model,
                          "connected": self.llm.connected})

        @app.route('/api/request', methods=['POST'])
        def api_submit_request():
            """Human submits request through the glass window."""
            data = request.json
            message = data.get('message', '').strip()
            if not message:
                return jsonify({"success": False, "error": "Empty message"})
            # Security check: human can submit requests
            access = self.security.check_access("human", "submit", "request_window")
            if not access.granted:
                return jsonify({"success": False, "error": "Access denied"})
            result = self._run_async(self.arbiter.submit_request(message))
            return jsonify({"success": True, "request": result.to_dict()})

        @app.route('/api/request/history')
        def api_request_history():
            return jsonify(self.arbiter.get_history(30))

        @app.route('/api/capabilities')
        def api_capabilities():
            return jsonify(self.capabilities.get_capability_list())

        @app.route('/api/capabilities/execute', methods=['POST'])
        def api_exec_capability():
            data = request.json
            cap_id = data.get('capability', '')
            params = data.get('params', {})
            cap_map = {
                "dream": self.capabilities.dream,
                "introspect": self.capabilities.introspect,
                "hypothesize": lambda: self.capabilities.hypothesize(params.get("topic", "")),
                "strategize": lambda: self.capabilities.strategize(params.get("goal", "")),
                "emotional_model": self.capabilities.emotional_model,
                "code_generate": lambda: self.capabilities.code_generate(params.get("description", "")),
                "world_model": self.capabilities.world_model,
                "predict": lambda: self.capabilities.predict(params.get("scenario", "")),
                "philosophical_reasoning": lambda: self.capabilities.philosophical_reasoning(params.get("question", "")),
                "teach": lambda: self.capabilities.teach(params.get("topic", "")),
            }
            fn = cap_map.get(cap_id)
            if not fn: return jsonify({"success": False, "error": f"Unknown capability: {cap_id}"})
            result = self._run_async(fn())
            return jsonify({"success": True, "result": result})

        @app.route('/api/cycle', methods=['POST'])
        def api_trigger_cycle():
            """Trigger an autonomous thinking cycle."""
            thought = self._run_async(self.brain.think())
            if thought.requires_action:
                plan = self._run_async(self.planner.generate_plan(thought))
                self._run_async(self.planner.execute_plan(plan))
            # Evolution check periodically
            if self.brain.thought_count % self.config.evolution_check_interval == 0:
                self._run_async(self.evolution.evaluate_and_evolve())
            # Memory consolidation
            if self.brain.thought_count % self.config.memory_consolidation_interval == 0:
                self._run_async(self.memory.consolidate())
            # Meta-AI evaluation
            self._run_async(self.meta_ai.evaluate_and_direct())
            return jsonify({"success": True, "thought": thought.to_dict(),
                          "cycle": self.brain.thought_count})

        @app.route('/api/directives')
        def api_directives():
            return jsonify(self.meta_ai.get_directive_history(20))

    def run(self, loop=None):
        self.loop = loop
        self.app.run(host=self.config.host, port=self.config.port, debug=False, use_reloader=False)
