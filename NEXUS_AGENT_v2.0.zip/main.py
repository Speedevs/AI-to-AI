#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════╗
║             N E X U S   A G E N T   v2.0                        ║
║        Autonomous Self-Evolving AI Agent with GUI Dashboard      ║
║                                                                  ║
║  Features:                                                       ║
║   • Autonomous AI Brain with self-reflection                     ║
║   • Meta-AI overseer (AI managing AI)                            ║
║   • Glass Window: humans talk, AI decides                        ║
║   • Universal LLM support (any AI platform)                      ║
║   • Self-evolution through mutation & selection                   ║
║   • Multi-layered memory with consolidation                      ║
║   • Web-based GUI dashboard                                      ║
║   • 10+ revolutionary AI capabilities                            ║
╚══════════════════════════════════════════════════════════════════╝
"""

import sys, os, asyncio, threading, signal, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config.settings import NexusConfig
from core.security import SecurityGate
from core.memory_system import MemorySystem
from core.tool_registry import ToolRegistry
from core.planning_engine import PlanningEngine
from core.evolution_engine import EvolutionEngine
from core.agent_brain import AgentBrain
from core.meta_ai import MetaAI
from core.llm_connector import LLMConnector
from core.request_arbiter import RequestArbiter
from core.capabilities import NexusCapabilities
from interface.web_server import NexusWebServer


def print_banner():
    print("""
\033[96m
    ███╗   ██╗███████╗██╗  ██╗██╗   ██╗███████╗  ██╗   ██╗██████╗ 
    ████╗  ██║██╔════╝╚██╗██╔╝██║   ██║██╔════╝  ██║   ██║╚════██╗
    ██╔██╗ ██║█████╗   ╚███╔╝ ██║   ██║███████╗  ██║   ██║ █████╔╝
    ██║╚██╗██║██╔══╝   ██╔██╗ ██║   ██║╚════██║  ╚██╗ ██╔╝██╔═══╝ 
    ██║ ╚████║███████╗██╔╝ ╚██╗╚██████╔╝███████║   ╚████╔╝ ███████╗
    ╚═╝  ╚═══╝╚══════╝╚═╝   ╚═╝ ╚═════╝ ╚══════╝    ╚═══╝  ╚══════╝
\033[0m
\033[93m    ═══ Autonomous Self-Evolving AI Agent — GUI Dashboard ═══\033[0m
""")


async def initialize_subsystems(config):
    """Initialize all subsystems in correct boot order."""
    print("\033[96m[NEXUS]\033[0m Booting subsystems...\n")
    
    security = SecurityGate(config)
    memory = MemorySystem(config, security)
    tools = ToolRegistry(config, security)
    planner = PlanningEngine(config, security, memory)
    evolution = EvolutionEngine(config, security, memory)
    llm = LLMConnector(config)
    
    brain = AgentBrain(config, security, memory, tools, planner, evolution)
    meta_ai = MetaAI(config, security, brain, memory, evolution)
    arbiter = RequestArbiter(config, security, memory, llm)
    capabilities = NexusCapabilities(memory, llm)
    
    subsystems = [
        ("Security Gate", security),
        ("Memory System", memory),
        ("Tool Registry", tools),
        ("Planning Engine", planner),
        ("Evolution Engine", evolution),
        ("LLM Connector", llm),
        ("Agent Brain", brain),
        ("Meta-AI Overseer", meta_ai),
        ("Request Arbiter", arbiter),
    ]
    
    for name, subsys in subsystems:
        try:
            await subsys.initialize()
            print(f"  \033[92m✓\033[0m {name:<22} \033[92mONLINE\033[0m")
        except Exception as e:
            print(f"  \033[91m✗\033[0m {name:<22} \033[91mFAILED: {e}\033[0m")
    
    print(f"\n\033[92m[NEXUS]\033[0m All subsystems online.\n")
    
    return {
        'config': config, 'security': security, 'memory': memory,
        'tools': tools, 'planner': planner, 'evolution': evolution,
        'brain': brain, 'meta_ai': meta_ai, 'llm': llm,
        'arbiter': arbiter, 'capabilities': capabilities,
    }


def run_autonomous_loop(systems, loop):
    """Background thread running autonomous thinking cycles."""
    async def cycle():
        brain = systems['brain']
        planner = systems['planner']
        evolution = systems['evolution']
        meta_ai = systems['meta_ai']
        memory = systems['memory']
        config = systems['config']
        
        cycle_count = 0
        while True:
            try:
                cycle_count += 1
                # Think
                thought = await brain.think()
                
                # Plan and execute if action needed
                if thought.requires_action:
                    plan = await planner.generate_plan(thought)
                    results = await planner.execute_plan(plan)
                    await brain.process_results(results)
                
                # Meta-AI evaluation
                if cycle_count % config.meta_evaluation_interval == 0:
                    await meta_ai.evaluate_and_direct()
                
                # Evolution
                if cycle_count % config.evolution_check_interval == 0:
                    await evolution.evaluate_and_evolve()
                
                # Memory consolidation
                if cycle_count % config.memory_consolidation_interval == 0:
                    await memory.consolidate()
                
                await asyncio.sleep(config.base_cycle_interval)
            except Exception as e:
                await brain.handle_error(e)
                await asyncio.sleep(5)
    
    asyncio.set_event_loop(loop)
    loop.run_until_complete(cycle())


def main():
    print_banner()
    
    config = NexusConfig()
    
    # Parse CLI args
    port = config.port
    for i, arg in enumerate(sys.argv[1:], 1):
        if arg.startswith('--port='):
            port = int(arg.split('=')[1])
            config.port = port
        elif arg == '--no-auto':
            config.base_cycle_interval = 999999  # Effectively disable auto
    
    # Initialize subsystems
    loop = asyncio.new_event_loop()
    systems = loop.run_until_complete(initialize_subsystems(config))
    
    # Create web server
    server = NexusWebServer(
        config=config,
        brain=systems['brain'],
        meta_ai=systems['meta_ai'],
        memory=systems['memory'],
        security=systems['security'],
        evolution=systems['evolution'],
        tools=systems['tools'],
        planner=systems['planner'],
        llm=systems['llm'],
        arbiter=systems['arbiter'],
        capabilities=systems['capabilities'],
    )
    
    # Start autonomous loop in background
    auto_loop = asyncio.new_event_loop()
    auto_thread = threading.Thread(target=run_autonomous_loop, args=(systems, auto_loop), daemon=True)
    auto_thread.start()
    
    print("\033[93m" + "═" * 60 + "\033[0m")
    print(f"\033[93m  NEXUS AGENT v2.0 — GUI Dashboard\033[0m")
    print(f"\033[93m  Open in browser: http://localhost:{port}\033[0m")
    print(f"\033[93m  Human access: VIEW + REQUEST WINDOW\033[0m")
    print(f"\033[93m  AI control: AUTONOMOUS + META-AI\033[0m")
    print("\033[93m" + "═" * 60 + "\033[0m\n")
    
    # Start Flask
    try:
        server.run(loop=auto_loop)
    except KeyboardInterrupt:
        print("\n\033[93m[NEXUS]\033[0m Shutting down...")
        loop.run_until_complete(systems['memory'].persist())
        loop.run_until_complete(systems['evolution'].save_state())
        print("\033[96m[NEXUS]\033[0m Goodbye.\n")


if __name__ == "__main__":
    main()
