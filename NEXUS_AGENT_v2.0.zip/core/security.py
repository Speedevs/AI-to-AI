"""
SECURITY GATE — AI-only control, Human view-only + request window
"""
import hashlib, hmac, secrets, time, json
from datetime import datetime
from enum import Enum, auto
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set
from collections import defaultdict

class AccessLevel(Enum):
    DENIED = 0
    HUMAN_VIEW_ONLY = 1
    HUMAN_REQUEST = 2  # NEW: Can submit requests (but AI decides)
    AI_LIMITED = 3
    AI_FULL_CONTROL = 4
    SYSTEM = 5
    META_AI = 6

class AccessorType(Enum):
    HUMAN = "human"
    AI_AGENT = "ai"
    META_AI = "meta_ai"
    TOOL = "tool"
    SYSTEM = "system"

@dataclass
class AccessResult:
    granted: bool
    level: AccessLevel
    reason: str
    accessor: str
    resource: str
    action: str
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    def __bool__(self): return self.granted

@dataclass
class AuditEntry:
    timestamp: str
    accessor_type: str
    action: str
    resource: str
    granted: bool
    reason: str

class SecurityGate:
    RESOURCE_PERMISSIONS = {
        "agent_brain": {
            "view": AccessLevel.HUMAN_VIEW_ONLY,
            "submit_request": AccessLevel.HUMAN_REQUEST,
            "modify": AccessLevel.AI_FULL_CONTROL,
            "override": AccessLevel.META_AI,
            "shutdown": AccessLevel.META_AI,
        },
        "memory": {
            "view": AccessLevel.HUMAN_VIEW_ONLY,
            "read": AccessLevel.AI_LIMITED,
            "write": AccessLevel.AI_FULL_CONTROL,
            "delete": AccessLevel.META_AI,
        },
        "planning": {
            "view": AccessLevel.HUMAN_VIEW_ONLY,
            "create_plan": AccessLevel.AI_FULL_CONTROL,
            "execute_plan": AccessLevel.AI_FULL_CONTROL,
        },
        "evolution": {
            "view": AccessLevel.HUMAN_VIEW_ONLY,
            "trigger": AccessLevel.AI_FULL_CONTROL,
            "approve_mutation": AccessLevel.META_AI,
        },
        "tools": {
            "view": AccessLevel.HUMAN_VIEW_ONLY,
            "execute": AccessLevel.AI_FULL_CONTROL,
            "register": AccessLevel.AI_FULL_CONTROL,
        },
        "agent_state": {
            "view": AccessLevel.HUMAN_VIEW_ONLY,
            "modify": AccessLevel.AI_FULL_CONTROL,
        },
        "configuration": {
            "view": AccessLevel.HUMAN_VIEW_ONLY,
            "modify": AccessLevel.META_AI,
        },
        "request_window": {
            "submit": AccessLevel.HUMAN_REQUEST,
            "decide": AccessLevel.AI_FULL_CONTROL,
            "view": AccessLevel.HUMAN_VIEW_ONLY,
        },
        "logs": {
            "view": AccessLevel.HUMAN_VIEW_ONLY,
            "write": AccessLevel.SYSTEM,
        },
    }

    ACCESSOR_LEVELS = {
        AccessorType.HUMAN: AccessLevel.HUMAN_REQUEST,
        AccessorType.AI_AGENT: AccessLevel.AI_FULL_CONTROL,
        AccessorType.META_AI: AccessLevel.META_AI,
        AccessorType.TOOL: AccessLevel.AI_LIMITED,
        AccessorType.SYSTEM: AccessLevel.SYSTEM,
    }

    def __init__(self, config):
        self.config = config
        self.audit_log: List[AuditEntry] = []
        self.ai_tokens: Dict[str, Dict] = {}
        self.rate_limiter: Dict[str, List[float]] = defaultdict(list)
        self.initialized = False

    async def initialize(self):
        master = secrets.token_hex(64)
        for comp in ["agent_brain", "meta_ai", "planning", "evolution", "memory", "tools"]:
            token = hashlib.sha256(f"{comp}:{master}:{time.time()}".encode()).hexdigest()
            self.ai_tokens[comp] = {"token": token, "active": True,
                "level": AccessLevel.META_AI if comp == "meta_ai" else AccessLevel.AI_FULL_CONTROL}
        self.initialized = True

    def check_access(self, accessor_type: str, action: str, resource: str, **kw) -> AccessResult:
        try: accessor_enum = AccessorType(accessor_type)
        except ValueError: accessor_enum = AccessorType.HUMAN
        
        accessor_level = self.ACCESSOR_LEVELS.get(accessor_enum, AccessLevel.DENIED)
        resource_perms = self.RESOURCE_PERMISSIONS.get(resource, {})
        required_level = resource_perms.get(action)
        
        if required_level is None:
            result = AccessResult(False, accessor_level, f"Unknown action '{action}'", accessor_type, resource, action)
            self._log(accessor_type, action, resource, False, result.reason)
            return result
        
        granted = accessor_level.value >= required_level.value
        reason = f"{'Granted' if granted else 'Denied'}: {accessor_enum.value} has {accessor_level.name} ({'≥' if granted else '<'} {required_level.name})"
        self._log(accessor_type, action, resource, granted, reason)
        return AccessResult(granted, accessor_level, reason, accessor_type, resource, action)

    def _log(self, accessor, action, resource, granted, reason):
        if self.config.audit_log_enabled:
            self.audit_log.append(AuditEntry(datetime.now().isoformat(), accessor, action, resource, granted, reason))
            if len(self.audit_log) > 5000: self.audit_log = self.audit_log[-2500:]

    def get_audit_log(self, n=50):
        return [{"timestamp": e.timestamp, "accessor": e.accessor_type, "action": e.action,
                 "resource": e.resource, "granted": e.granted, "reason": e.reason}
                for e in self.audit_log[-n:]]

    def get_summary(self):
        total = len(self.audit_log)
        denied = sum(1 for e in self.audit_log if not e.granted)
        return {"status": "ACTIVE", "total_checks": total, "denied": denied,
                "denial_rate": round(denied / max(total, 1), 3),
                "human_level": "REQUEST_WINDOW", "ai_level": "FULL_CONTROL", "meta_level": "SUPREME"}
