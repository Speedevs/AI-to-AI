"""EVOLUTION ENGINE — Self-improvement through mutation and selection"""
import json, random, copy, math, time
from datetime import datetime
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any

EVOLVABLE = {
    "creativity_factor": (0.1, 1.0), "confidence_threshold": (0.3, 0.9),
    "max_reasoning_depth": (3, 15), "memory_importance_decay": (0.99, 0.999),
    "forgetting_threshold": (0.05, 0.3), "mutation_rate": (0.05, 0.3),
    "meta_optimization_aggression": (0.1, 0.9),
}

POTENTIAL_CAPS = [
    "deep_reasoning", "creative_synthesis", "pattern_recognition", "self_optimization",
    "predictive_modeling", "knowledge_integration", "adaptive_planning", "error_recovery",
    "meta_cognition", "strategic_foresight", "emotional_modeling", "causal_inference",
    "anomaly_detection", "abstract_reasoning", "collaborative_reasoning", "dream_weaving",
    "philosophical_thought", "code_generation", "world_modeling", "teaching",
]

@dataclass
class Mutation:
    id: str; parameter: str; old_val: Any; new_val: Any; generation: int
    fitness_before: float; fitness_after: Optional[float] = None; accepted: Optional[bool] = None
    def to_dict(self):
        return {"id": self.id, "param": self.parameter, "old": str(self.old_val), "new": str(self.new_val),
                "gen": self.generation, "accepted": self.accepted}

class EvolutionEngine:
    def __init__(self, config, security, memory):
        self.config = config; self.security = security; self.memory = memory
        self.generation = 0; self.fitness_score = 0.5; self.fitness_history = []
        self.params: Dict[str, Any] = {}; self.capabilities: List[str] = []
        self.cap_levels: Dict[str, float] = {}
        self.mutations_attempted = 0; self.mutations_kept = 0
        self.mutation_history: List[Mutation] = []; self.perf_buffer: List[float] = []
        self.initialized = False

    async def initialize(self):
        for p in EVOLVABLE:
            if hasattr(self.config, p): self.params[p] = getattr(self.config, p)
        self.capabilities = ["deep_reasoning", "pattern_recognition", "error_recovery", "meta_cognition"]
        for c in self.capabilities: self.cap_levels[c] = 0.5
        self.fitness_score = await self._eval_fitness()
        self.fitness_history.append(self.fitness_score)
        self.initialized = True

    async def evaluate_and_evolve(self):
        fitness = await self._eval_fitness()
        self.fitness_score = fitness; self.fitness_history.append(fitness)
        if random.random() < self.config.mutation_rate:
            mut = self._propose_mutation()
            if mut:
                self.params[mut.parameter] = mut.new_val
                new_f = await self._eval_fitness(); mut.fitness_after = new_f
                if new_f >= mut.fitness_before:
                    mut.accepted = True; self.mutations_kept += 1; self.fitness_score = new_f
                    if hasattr(self.config, mut.parameter): setattr(self.config, mut.parameter, mut.new_val)
                else:
                    mut.accepted = False; self.params[mut.parameter] = mut.old_val
                self.mutation_history.append(mut)
        await self._check_emergence()
        self.generation += 1

    async def _eval_fitness(self) -> float:
        scores = [0.5]
        ms = self.memory.get_stats()
        if ms["total_entries"] > 0:
            scores.append(min(1.0, (ms["total_entries"]-ms["total_forgotten"])/max(ms["total_entries"],1)))
        if self.perf_buffer: scores.append(sum(self.perf_buffer)/len(self.perf_buffer))
        if self.cap_levels: scores.append(sum(self.cap_levels.values())/len(self.cap_levels))
        return sum(scores)/len(scores)

    def _propose_mutation(self) -> Optional[Mutation]:
        p = random.choice(list(EVOLVABLE.keys()))
        lo, hi = EVOLVABLE[p]; cur = self.params.get(p)
        if cur is None: return None
        self.mutations_attempted += 1
        if isinstance(cur, float):
            nv = max(lo, min(hi, round(cur + random.gauss(0, (hi-lo)*0.1), 4)))
        elif isinstance(cur, int):
            nv = max(int(lo), min(int(hi), cur + random.randint(-max(1,int((hi-lo)*0.15)), max(1,int((hi-lo)*0.15)))))
        else: return None
        return Mutation(f"MUT-{self.generation:04d}-{self.mutations_attempted:04d}",
                       p, cur, nv, self.generation, self.fitness_score)

    async def _check_emergence(self):
        if self.fitness_score > 0.65 and self.generation > 3:
            avail = [c for c in POTENTIAL_CAPS if c not in self.capabilities]
            if avail and random.random() < 0.12:
                nc = random.choice(avail); self.capabilities.append(nc); self.cap_levels[nc] = 0.3
        for c in self.capabilities:
            if random.random() < 0.08:
                self.cap_levels[c] = min(1.0, self.cap_levels.get(c, 0.3) + random.uniform(0.01, 0.04))

    def record_performance(self, score: float):
        self.perf_buffer.append(score)
        if len(self.perf_buffer) > self.config.fitness_window:
            self.perf_buffer = self.perf_buffer[-self.config.fitness_window:]

    def get_status(self):
        return {"generation": self.generation, "fitness_score": round(self.fitness_score, 4),
                "mutations_attempted": self.mutations_attempted, "mutations_kept": self.mutations_kept,
                "mutation_acceptance_rate": round(self.mutations_kept/max(self.mutations_attempted,1), 3),
                "capabilities": self.capabilities, "capability_levels": {k:round(v,3) for k,v in self.cap_levels.items()},
                "parameters": {k: round(v,4) if isinstance(v,float) else v for k,v in self.params.items()},
                "fitness_history": [round(f,3) for f in self.fitness_history[-30:]]}

    async def save_state(self):
        p = self.config.get_path("evolution_store"); p.mkdir(parents=True, exist_ok=True)
        with open(str(p/"evolution_state.json"), 'w') as f:
            json.dump(self.get_status(), f, indent=2)
