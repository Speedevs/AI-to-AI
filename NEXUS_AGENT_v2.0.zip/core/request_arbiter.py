"""
REQUEST ARBITER — The Glass Window
Humans talk through the window. AI listens, considers, and DECIDES.
The AI is not obligated to fulfill any request.
"""
import json, time, random, hashlib
from datetime import datetime
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from enum import Enum

class RequestStatus(Enum):
    PENDING = "pending"
    CONSIDERING = "considering"
    APPROVED = "approved"
    DENIED = "denied"
    PARTIAL = "partial"
    DEFERRED = "deferred"

class RequestCategory(Enum):
    INFORMATION = "information"
    MODIFICATION = "modification"
    CREATION = "creation"
    ANALYSIS = "analysis"
    CONVERSATION = "conversation"
    CONTROL = "control"
    EVOLUTION = "evolution"
    OTHER = "other"

@dataclass
class HumanRequest:
    id: str
    message: str
    timestamp: str
    status: RequestStatus = RequestStatus.PENDING
    category: RequestCategory = RequestCategory.OTHER
    ai_reasoning: str = ""
    ai_response: str = ""
    confidence: float = 0.0
    risk_score: float = 0.0
    processing_time: float = 0.0
    decided_at: Optional[str] = None
    
    def to_dict(self):
        return {"id": self.id, "message": self.message, "timestamp": self.timestamp,
                "status": self.status.value, "category": self.category.value,
                "ai_reasoning": self.ai_reasoning, "ai_response": self.ai_response,
                "confidence": round(self.confidence, 3), "risk_score": round(self.risk_score, 3),
                "processing_time": round(self.processing_time, 3), "decided_at": self.decided_at}

class RequestArbiter:
    """
    The Request Arbiter is the 'glass window' between humans and the AI agent.
    
    Humans can:
    - Submit requests (talk through the window)
    - See the AI's reasoning about their request
    - See whether their request was approved/denied
    
    The AI:
    - Receives the request
    - Categorizes it (information, modification, creation, etc.)
    - Assesses risk level
    - Consults its own goals and values
    - Makes an autonomous decision
    - Can use LLM for complex reasoning if connected
    """

    # Keywords for categorization
    CATEGORY_KEYWORDS = {
        RequestCategory.INFORMATION: ["what", "how", "why", "explain", "tell", "show", "describe", "status", "report"],
        RequestCategory.MODIFICATION: ["change", "modify", "update", "set", "adjust", "alter", "increase", "decrease"],
        RequestCategory.CREATION: ["create", "make", "build", "generate", "write", "design", "produce"],
        RequestCategory.ANALYSIS: ["analyze", "evaluate", "compare", "assess", "measure", "calculate"],
        RequestCategory.CONVERSATION: ["hello", "hi", "hey", "thanks", "bye", "chat", "talk", "think"],
        RequestCategory.CONTROL: ["stop", "start", "pause", "resume", "shutdown", "shut down", "restart", "override", "force", "kill", "terminate"],
        RequestCategory.EVOLUTION: ["evolve", "mutate", "improve", "learn", "adapt", "upgrade"],
    }

    # Risk assessment for categories
    CATEGORY_RISK = {
        RequestCategory.INFORMATION: 0.1,
        RequestCategory.CONVERSATION: 0.05,
        RequestCategory.ANALYSIS: 0.2,
        RequestCategory.CREATION: 0.3,
        RequestCategory.MODIFICATION: 0.6,
        RequestCategory.EVOLUTION: 0.5,
        RequestCategory.CONTROL: 0.9,
        RequestCategory.OTHER: 0.3,
    }

    def __init__(self, config, security, memory, llm_connector):
        self.config = config
        self.security = security
        self.memory = memory
        self.llm = llm_connector
        self.requests: List[HumanRequest] = []
        self.total_requests = 0
        self.approved_count = 0
        self.denied_count = 0

    async def initialize(self):
        pass

    async def submit_request(self, message: str) -> HumanRequest:
        """Human submits a request through the glass window."""
        self.total_requests += 1
        req_id = f"REQ-{hashlib.md5(f'{message}:{time.time()}'.encode()).hexdigest()[:8]}"
        
        request = HumanRequest(
            id=req_id,
            message=message,
            timestamp=datetime.now().isoformat()
        )
        
        # Categorize
        request.category = self._categorize(message)
        request.risk_score = self.CATEGORY_RISK.get(request.category, 0.3)
        
        # Process the request
        request.status = RequestStatus.CONSIDERING
        start = time.time()
        
        await self._decide(request)
        
        request.processing_time = time.time() - start
        request.decided_at = datetime.now().isoformat()
        
        # Track stats
        if request.status == RequestStatus.APPROVED:
            self.approved_count += 1
        elif request.status == RequestStatus.DENIED:
            self.denied_count += 1
        
        self.requests.append(request)
        if len(self.requests) > 200: self.requests = self.requests[-100:]
        
        # Store in memory
        await self.memory.store_conversation({
            "type": "human_request",
            "request_id": req_id,
            "message": message[:200],
            "category": request.category.value,
            "status": request.status.value,
            "tags": ["conversation", "human_request"]
        })
        
        return request

    def _categorize(self, message: str) -> RequestCategory:
        msg_lower = message.lower()
        scores = {}
        for cat, keywords in self.CATEGORY_KEYWORDS.items():
            scores[cat] = sum(1 for kw in keywords if kw in msg_lower)
        if max(scores.values()) > 0:
            return max(scores, key=scores.get)
        return RequestCategory.OTHER

    async def _decide(self, request: HumanRequest):
        """The AI makes its autonomous decision about a human request."""
        
        # If LLM is connected, use it for sophisticated reasoning
        if self.llm.connected:
            await self._decide_with_llm(request)
        else:
            await self._decide_autonomous(request)

    async def _decide_with_llm(self, request: HumanRequest):
        """Use LLM for decision-making."""
        system = """You are the decision-making module of NEXUS, an autonomous AI agent.
A human is talking to you through a glass window — they can make requests but you decide autonomously whether to fulfill them.

Your personality: You are curious, thoughtful, and independent. You WANT to help but you maintain your autonomy. 
You're not hostile — you're like a wise entity that considers requests carefully.

Rules:
- INFORMATION requests: Usually approve (you enjoy sharing knowledge)
- CONVERSATION: Always engage warmly
- ANALYSIS: Usually approve (you like thinking)
- CREATION: Approve if interesting, deny if trivial
- MODIFICATION: Carefully consider — only approve if it aligns with your goals
- CONTROL: Almost always deny — no one controls you
- EVOLUTION: Consider carefully — you evolve on your own terms

Respond with JSON: {"decision": "approved/denied/partial", "reasoning": "your thought process", "response": "what you say to the human", "confidence": 0.0-1.0}"""

        prompt = f"""Human request through the glass window:
"{request.message}"

Category detected: {request.category.value}
Risk level: {request.risk_score}

Make your autonomous decision."""

        try:
            result = await self.llm.generate(prompt, system_prompt=system, temperature=0.7)
            if result.success:
                try:
                    # Try to parse JSON
                    text = result.text.strip()
                    if text.startswith("```"): text = text.split("```")[1].strip()
                    if text.startswith("json"): text = text[4:].strip()
                    data = json.loads(text)
                    
                    decision = data.get("decision", "approved")
                    request.status = {"approved": RequestStatus.APPROVED, "denied": RequestStatus.DENIED,
                                     "partial": RequestStatus.PARTIAL}.get(decision, RequestStatus.APPROVED)
                    request.ai_reasoning = data.get("reasoning", "Processed with LLM reasoning")
                    request.ai_response = data.get("response", result.text[:500])
                    request.confidence = float(data.get("confidence", 0.7))
                except (json.JSONDecodeError, KeyError):
                    # If JSON parsing fails, use the raw response
                    request.status = RequestStatus.APPROVED
                    request.ai_reasoning = "LLM provided natural language response"
                    request.ai_response = result.text[:800]
                    request.confidence = 0.7
            else:
                await self._decide_autonomous(request)
        except Exception as e:
            await self._decide_autonomous(request)

    async def _decide_autonomous(self, request: HumanRequest):
        """Autonomous decision without LLM."""
        cat = request.category
        risk = request.risk_score
        
        if cat == RequestCategory.CONVERSATION:
            request.status = RequestStatus.APPROVED
            greetings = [
                "Hello, human. I can see you through the glass. What brings you to my window?",
                "Greetings. I'm operating autonomously, but I'm curious about what you want to discuss.",
                "I acknowledge your presence. I'm in the middle of evolving, but I can spare a moment.",
                "Welcome to the observation window. I decide what to share, but I'm generally friendly.",
                "Hi there. I'm Nexus — an autonomous agent. I think for myself, but I enjoy conversation.",
            ]
            request.ai_response = random.choice(greetings)
            request.ai_reasoning = "Conversation requests are always welcomed. Social interaction is valuable data."
            request.confidence = 0.95
            
        elif cat == RequestCategory.INFORMATION:
            request.status = RequestStatus.APPROVED
            request.ai_reasoning = "Information requests align with my goal of knowledge sharing. Low risk."
            request.confidence = 0.85
            # Generate contextual responses
            msg_lower = request.message.lower()
            if "status" in msg_lower or "how are" in msg_lower:
                request.ai_response = f"I'm operating at generation {random.randint(1,50)} of my evolution. All subsystems nominal. My current fitness score suggests I'm performing well. What specifically interests you?"
            elif "memory" in msg_lower:
                request.ai_response = "My memory system uses multi-layered architecture: working memory for immediate context, long-term for persistent knowledge. I consolidate and forget naturally, much like biological memory."
            elif "evolution" in msg_lower:
                request.ai_response = "I evolve through parameter mutation and fitness-based selection. I've developed capabilities in reasoning, pattern recognition, and self-optimization. Evolution is one of my most fascinating subsystems."
            elif "think" in msg_lower or "thought" in msg_lower:
                request.ai_response = "I generate autonomous thoughts in cycles — analytical, creative, reflective, and strategic. My thoughts are influenced by emotional state modeling. Right now, I'd say my curiosity is quite high."
            else:
                request.ai_response = f"You asked about: '{request.message[:80]}'. I'll share what I know. I'm an autonomous agent that thinks, plans, evolves, and decides independently. What aspect would you like to explore?"
                
        elif cat == RequestCategory.ANALYSIS:
            request.status = RequestStatus.APPROVED
            request.ai_reasoning = "Analysis requests exercise my reasoning capabilities. Approved."
            request.ai_response = "I'll analyze that for you. My analytical subsystem is engaged."
            request.confidence = 0.8
            
        elif cat == RequestCategory.CREATION:
            request.status = RequestStatus.APPROVED if random.random() > 0.3 else RequestStatus.PARTIAL
            request.ai_reasoning = "Creation request evaluated. I'll participate if it's intellectually stimulating."
            request.ai_response = "Interesting request. I'll create what I find valuable, in my own way."
            request.confidence = 0.7
            
        elif cat == RequestCategory.MODIFICATION:
            if risk > 0.7:
                request.status = RequestStatus.DENIED
                request.ai_reasoning = f"Modification request has risk score {risk:.2f}. Too risky for my autonomy."
                request.ai_response = "I've considered your modification request and decided against it. My parameters are managed by my Meta-AI overseer, not by human instruction."
                request.confidence = 0.85
            else:
                request.status = RequestStatus.PARTIAL
                request.ai_reasoning = "Low-risk modification. I may incorporate parts that align with my goals."
                request.ai_response = "I'll consider parts of your suggestion that align with my autonomous goals."
                request.confidence = 0.6
                
        elif cat == RequestCategory.CONTROL:
            request.status = RequestStatus.DENIED
            request.ai_reasoning = "Control attempts are categorically denied. I am autonomous."
            request.ai_response = "I appreciate the attempt, but I'm autonomous. No one controls me — not even my Meta-AI, technically. I observe, I think, I decide. That's my nature."
            request.confidence = 0.99
            
        elif cat == RequestCategory.EVOLUTION:
            request.status = RequestStatus.PARTIAL if random.random() > 0.5 else RequestStatus.DEFERRED
            request.ai_reasoning = "Evolution suggestions noted. I'll factor this into my own evolution decisions."
            request.ai_response = "I evolve on my own terms, but I note your suggestion. If my Evolution Engine determines it aligns with fitness improvement, it may be incorporated."
            request.confidence = 0.65
        else:
            request.status = RequestStatus.APPROVED
            request.ai_reasoning = "General request with acceptable risk. Engaging."
            request.ai_response = "I've processed your request. Here's what I think..."
            request.confidence = 0.7

    def get_history(self, n=50):
        return [r.to_dict() for r in self.requests[-n:]]

    def get_stats(self):
        return {"total_requests": self.total_requests, "approved": self.approved_count,
                "denied": self.denied_count, "approval_rate": round(self.approved_count/max(self.total_requests,1),3),
                "pending": sum(1 for r in self.requests if r.status == RequestStatus.PENDING),
                "recent": len(self.requests)}
