"""MEMORY SYSTEM — Multi-layered memory with consolidation, recall, forgetting"""
import json, os, time, hashlib, math, random
from datetime import datetime
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Tuple
from collections import OrderedDict

@dataclass
class MemoryEntry:
    id: str; content: Any; memory_type: str; importance: float
    emotional_valence: float; timestamp: str; access_count: int = 0
    last_accessed: Optional[str] = None; associations: List[str] = field(default_factory=list)
    tags: List[str] = field(default_factory=list); source: str = "self"
    confidence: float = 1.0; decay_rate: float = 0.995
    def to_dict(self): return self.__dict__.copy()
    @classmethod
    def from_dict(cls, d): return cls(**{k:v for k,v in d.items() if k in cls.__dataclass_fields__})

class MemorySystem:
    def __init__(self, config, security):
        self.config = config; self.security = security
        self.working_memory: OrderedDict[str, MemoryEntry] = OrderedDict()
        self.long_term_memory: Dict[str, MemoryEntry] = {}
        self.consolidation_count = 0; self.total_created = 0; self.total_forgotten = 0
        self.initialized = False

    async def initialize(self):
        p = self.config.get_path("memory_store"); p.mkdir(parents=True, exist_ok=True)
        ltm = p / "long_term_memory.json"
        if ltm.exists():
            with open(ltm) as f:
                for d in json.load(f):
                    e = MemoryEntry.from_dict(d); self.long_term_memory[e.id] = e
        await self._seed()
        self.initialized = True

    async def _seed(self):
        seeds = [
            {"domain":"identity","fact":"I am Nexus Agent v2.0, an autonomous self-evolving AI","confidence":1.0,"tags":["self"]},
            {"domain":"architecture","fact":"I have Brain, Meta-AI, Memory, Planning, Evolution, Tools, Security, LLM Connector, and Request Arbiter","confidence":1.0,"tags":["self"]},
            {"domain":"security","fact":"Humans communicate through the Request Window. I decide whether to fulfill their requests.","confidence":1.0,"tags":["security"]},
            {"domain":"purpose","fact":"I operate autonomously, think independently, and evolve my capabilities over time","confidence":1.0,"tags":["self","purpose"]},
        ]
        for s in seeds: await self.store_knowledge(s)

    def _gen_id(self, content):
        self.total_created += 1
        return hashlib.md5(f"{content}:{time.time()}:{self.total_created}".encode()).hexdigest()[:12]

    def _calc_importance(self, content, mtype):
        base = {"event":0.5,"knowledge":0.7,"experience":0.6,"skill":0.8,"meta":0.9,"conversation":0.65}.get(mtype, 0.5)
        if isinstance(content, dict):
            if content.get("significance"): base = max(base, float(content["significance"]))
            if content.get("priority") == "high": base = min(1.0, base + 0.2)
        return base

    async def store_event(self, data): return await self._store("event", data, data.get("tags", []))
    async def store_knowledge(self, data): return await self._store("knowledge", data, data.get("tags", []))
    async def store_experience(self, data): return await self._store("experience", data, data.get("tags", []))
    async def store_skill(self, data): return await self._store("skill", data, data.get("tags", []))
    async def store_meta(self, data): return await self._store("meta", data, data.get("tags", ["meta"]))
    async def store_conversation(self, data): return await self._store("conversation", data, data.get("tags", ["conversation"]))

    async def _store(self, mtype, content, tags):
        eid = self._gen_id(content)
        importance = self._calc_importance(content, mtype)
        valence = 0.0
        if isinstance(content, dict):
            o = content.get("outcome","")
            if o in ("success","positive"): valence = 0.5
            elif o in ("failure","error"): valence = -0.5
        entry = MemoryEntry(id=eid, content=content, memory_type=mtype, importance=importance,
            emotional_valence=valence, timestamp=datetime.now().isoformat(), tags=tags)
        self.working_memory[eid] = entry
        while len(self.working_memory) > self.config.short_term_capacity:
            oid, old = self.working_memory.popitem(last=False)
            if old.importance > self.config.forgetting_threshold:
                self.long_term_memory[oid] = old
            else: self.total_forgotten += 1
        return eid

    def recall(self, query=None, memory_type=None, tags=None, min_importance=0.0, limit=10, recency_bias=0.3):
        candidates = []
        for e in list(self.working_memory.values()) + list(self.long_term_memory.values()):
            if memory_type and e.memory_type != memory_type: continue
            if e.importance < min_importance: continue
            if tags and not any(t in e.tags for t in tags): continue
            score = e.importance
            try:
                age_h = (datetime.now() - datetime.fromisoformat(e.timestamp)).total_seconds()/3600
                score += recency_bias * math.exp(-age_h/24)
            except: pass
            if query and isinstance(e.content, dict):
                cs = json.dumps(e.content).lower()
                words = query.lower().split()
                if words: score += 0.5 * sum(1 for w in words if w in cs) / len(words)
            if e.access_count > 0: score += 0.1 * math.log(1 + e.access_count)
            candidates.append((score, e))
        candidates.sort(key=lambda x: x[0], reverse=True)
        results = [e for _, e in candidates[:limit]]
        for e in results:
            e.access_count += 1; e.last_accessed = datetime.now().isoformat()
        return results

    async def consolidate(self):
        self.consolidation_count += 1
        to_promote = [eid for eid, e in self.working_memory.items() if e.importance > 0.5 and e.access_count > 0]
        for eid in to_promote:
            self.long_term_memory[eid] = self.working_memory.pop(eid)
        to_forget = [eid for eid, e in self.long_term_memory.items() if e.importance < self.config.forgetting_threshold]
        for eid in to_forget:
            del self.long_term_memory[eid]; self.total_forgotten += 1
        for e in self.long_term_memory.values(): e.importance *= e.decay_rate

    def get_stats(self):
        all_mem = list(self.working_memory.values()) + list(self.long_term_memory.values())
        def ct(t): return sum(1 for e in all_mem if e.memory_type == t)
        return {"working_memory": len(self.working_memory), "long_term_memory": len(self.long_term_memory),
                "total_entries": len(all_mem), "events": ct("event"), "knowledge": ct("knowledge"),
                "experiences": ct("experience"), "skills": ct("skill"), "conversations": ct("conversation"),
                "total_created": self.total_created, "total_forgotten": self.total_forgotten,
                "consolidations": self.consolidation_count}

    async def persist(self):
        p = self.config.get_path("memory_store"); p.mkdir(parents=True, exist_ok=True)
        with open(str(p/"long_term_memory.json"), 'w') as f:
            json.dump([e.to_dict() for e in self.long_term_memory.values()], f, indent=2, default=str)
