"""TOOL REGISTRY — Dynamic tool management"""
import time, asyncio, hashlib
from datetime import datetime
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Callable, Awaitable

@dataclass
class ToolResult:
    tool_name: str; success: bool; output: Any; error: Optional[str] = None
    execution_time: float = 0.0; timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    def to_dict(self):
        return {"tool": self.tool_name, "success": self.success, "output": str(self.output)[:300],
                "error": self.error, "time": round(self.execution_time, 3)}

class ToolRegistry:
    def __init__(self, config, security):
        self.config = config; self.security = security
        self.tools: Dict[str, Dict] = {}; self.history: List[ToolResult] = []
        self.initialized = False

    async def initialize(self):
        for name, desc in [
            ("analyze_pattern", "Analyze data for patterns and trends"),
            ("evaluate_hypothesis", "Test hypotheses against evidence"),
            ("generate_insight", "Generate cross-domain insights"),
            ("self_diagnostic", "Run self-diagnostic on subsystems"),
            ("compute_metrics", "Compute performance metrics"),
            ("synthesize_knowledge", "Synthesize from multiple memories"),
            ("monitor_performance", "Monitor real-time performance"),
            ("creative_solve", "Apply creative problem-solving"),
            ("sentiment_analysis", "Analyze emotional content of text"),
            ("anomaly_detection", "Detect anomalies in data patterns"),
            ("concept_mapping", "Map relationships between concepts"),
            ("decision_tree", "Generate decision trees for choices"),
        ]:
            self.tools[name] = {"name": name, "desc": desc, "enabled": True, "uses": 0, "successes": 0}
        self.initialized = True

    async def execute(self, tool_name: str, **kwargs) -> ToolResult:
        tool = self.tools.get(tool_name)
        if not tool: return ToolResult(tool_name, False, None, f"Tool '{tool_name}' not found")
        start = time.time()
        tool["uses"] += 1
        await asyncio.sleep(0.02)  # Simulate work
        output = {"tool": tool_name, "result": "executed", "params": str(kwargs)[:100]}
        tool["successes"] += 1
        r = ToolResult(tool_name, True, output, execution_time=time.time()-start)
        self.history.append(r)
        if len(self.history) > 200: self.history = self.history[-100:]
        return r

    def get_tools_list(self):
        return [{"name": t["name"], "desc": t["desc"], "enabled": t["enabled"],
                 "uses": t["uses"], "success_rate": f"{t['successes']/max(t['uses'],1):.0%}"}
                for t in self.tools.values()]

    def get_stats(self):
        total = sum(t["uses"] for t in self.tools.values())
        succ = sum(t["successes"] for t in self.tools.values())
        return {"total_tools": len(self.tools), "total_executions": total,
                "success_rate": round(succ/max(total,1), 3)}
