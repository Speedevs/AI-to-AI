"""PLANNING ENGINE — Goal decomposition and execution"""
import time, asyncio, hashlib
from datetime import datetime
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any

@dataclass
class PlanStep:
    id: str; description: str; action_type: str; status: str = "pending"
    result: Optional[Any] = None; duration: float = 0.0
    def to_dict(self): return {"id": self.id, "desc": self.description, "type": self.action_type, "status": self.status}

@dataclass
class Plan:
    id: str; goal: str; steps: List[PlanStep]; status: str = "draft"
    priority: float = 0.5; estimated_duration: float = 0.0; created_at: str = ""
    def to_dict(self):
        return {"id": self.id, "goal": self.goal[:80], "steps": [s.to_dict() for s in self.steps],
                "status": self.status, "priority": self.priority, "created_at": self.created_at}

class PlanningEngine:
    def __init__(self, config, security, memory):
        self.config = config; self.security = security; self.memory = memory
        self.active_plans: Dict[str, Plan] = {}; self.completed: List[Plan] = []
        self.total_plans = 0; self.total_steps = 0; self.initialized = False

    async def initialize(self): self.initialized = True

    async def generate_plan(self, goal_input) -> Plan:
        if isinstance(goal_input, dict): goal = goal_input.get("objective", goal_input.get("summary", str(goal_input)))
        elif hasattr(goal_input, 'summary'): goal = goal_input.summary
        else: goal = str(goal_input)
        self.total_plans += 1
        pid = f"PLN-{hashlib.md5(f'{goal}:{time.time()}'.encode()).hexdigest()[:8]}"
        steps = [
            PlanStep(f"{pid}-S001", f"Analyze: {goal[:50]}", "reasoning"),
            PlanStep(f"{pid}-S002", "Gather context and knowledge", "tool"),
            PlanStep(f"{pid}-S003", "Generate solution approach", "reasoning"),
            PlanStep(f"{pid}-S004", f"Execute: {goal[:40]}", "tool"),
            PlanStep(f"{pid}-S005", "Evaluate outcome and learn", "reasoning"),
        ]
        plan = Plan(id=pid, goal=goal, steps=steps, estimated_duration=len(steps)*1.0,
                    created_at=datetime.now().isoformat())
        self.active_plans[pid] = plan
        return plan

    async def execute_plan(self, plan: Plan) -> List[Dict]:
        plan.status = "executing"; results = []
        for step in plan.steps:
            step.status = "running"; start = time.time()
            await asyncio.sleep(0.02)
            step.status = "completed"; step.duration = time.time()-start
            self.total_steps += 1
            results.append({"step": step.id, "success": True, "duration": step.duration})
        plan.status = "completed"
        if plan.id in self.active_plans: del self.active_plans[plan.id]
        self.completed.append(plan)
        return results

    def get_stats(self):
        return {"total_plans": self.total_plans, "active": len(self.active_plans),
                "completed": len(self.completed), "total_steps": self.total_steps,
                "success_rate": 1.0 if self.completed else 0.0}
