"""META-AI OVERSEER — The AI that manages the AI"""
import random, time
from datetime import datetime
from dataclasses import dataclass, field
from typing import Dict, List, Optional

@dataclass
class MetaDirective:
    id: str; directive_type: str; content: str; urgency: float; status: str = "active"
    target: str = "agent_brain"; params: Dict = field(default_factory=dict)
    issued_at: str = field(default_factory=lambda: datetime.now().isoformat())
    def to_dict(self):
        return {"id": self.id, "type": self.directive_type, "content": self.content,
                "urgency": round(self.urgency,2), "status": self.status, "target": self.target}

class MetaAI:
    DIMENSIONS = ["reasoning_quality","decision_accuracy","learning_rate","resource_efficiency",
                  "goal_progress","emotional_stability","error_recovery","creativity","self_awareness","adaptability"]

    def __init__(self, config, security, brain, memory, evolution):
        self.config = config; self.security = security; self.brain = brain
        self.memory = memory; self.evolution = evolution
        self.directives: List[MetaDirective] = []; self.eval_count = 0
        self.intervention_count = 0; self.total_directives = 0; self.meta_confidence = 0.7
        self.initialized = False

    async def initialize(self):
        await self._issue("priority", "Focus on stability during initial operation", 0.6)
        await self._issue("focus", "Build knowledge through exploration", 0.5)
        self.initialized = True

    async def evaluate_and_direct(self):
        self.eval_count += 1
        if self.eval_count % self.config.meta_evaluation_interval != 0:
            return MetaDirective("NOP", "none", "Nominal", 0.0, status="nominal")
        evaluation = await self._evaluate()
        overall = sum(evaluation.values()) / max(len(evaluation), 1)
        critical = [d for d, s in evaluation.items() if s < 0.3]
        if critical:
            self.intervention_count += 1
            return await self._issue("warning", f"Critical: {', '.join(critical)}", 0.9, params={"critical": critical})
        if overall > 0.6 and random.random() < self.config.meta_optimization_aggression:
            weak = min(evaluation, key=evaluation.get)
            return await self._issue("optimize", f"Optimizing: {weak}", 0.4)
        return MetaDirective("META-NOM", "status", f"Nominal. Score: {overall:.2f}", 0.1, status="nominal")

    async def _evaluate(self) -> Dict[str, float]:
        scores = {}
        recent = list(self.brain.thought_history)[-10:]
        scores["reasoning_quality"] = min(1.0, (sum(t.confidence for t in recent)/max(len(recent),1) + sum(t.reasoning_depth for t in recent)/max(len(recent),1)/7) / 2) if recent else 0.5
        scores["decision_accuracy"] = self.brain.planner.get_stats().get("success_rate", 0.5)
        evo = self.evolution.get_status()
        ft = evo.get("fitness_history", [])
        scores["learning_rate"] = max(0, min(1, 0.5 + (ft[-1]-ft[0])*5)) if len(ft) >= 2 else 0.5
        ms = self.memory.get_stats()
        scores["resource_efficiency"] = 1.0 - (ms["total_forgotten"]/max(ms["total_created"],1))
        scores["goal_progress"] = 0.6 if self.brain.goals else 0.3
        em = self.brain.emotional_state
        scores["emotional_stability"] = 1.0/(1.0 + sum((v-0.5)**2 for v in em.values())/max(len(em),1)*5) if em else 0.5
        scores["error_recovery"] = max(0.1, 0.9 - self.brain.error_count * 0.05)
        scores["creativity"] = min(1.0, 0.3 + sum(1 for t in recent if t.thought_type=="creative")*0.15) if recent else 0.3
        scores["self_awareness"] = min(1.0, 0.4 + sum(1 for t in recent if t.thought_type=="reflective")*0.12) if recent else 0.4
        scores["adaptability"] = min(1.0, 0.5 + evo.get("mutation_acceptance_rate", 0))
        return scores

    async def _issue(self, dtype, content, urgency, target="agent_brain", params=None):
        self.total_directives += 1
        d = MetaDirective(f"META-D{self.total_directives:04d}", dtype, content, urgency, target=target, params=params or {})
        self.directives.append(d)
        await self.memory.store_event({"type":"meta_directive","id":d.id,"content":content,"tags":["meta_ai"]})
        return d

    async def get_report(self):
        evaluation = await self._evaluate()
        overall = sum(evaluation.values()) / max(len(evaluation), 1)
        health = "EXCELLENT" if overall>0.7 else "GOOD" if overall>0.5 else "NEEDS_ATTENTION" if overall>0.3 else "CRITICAL"
        recs = [f"Improve {d.replace('_',' ')} ({s:.0%})" for d, s in sorted(evaluation.items(), key=lambda x:x[1]) if s < 0.6]
        return {"health": health, "score": round(overall, 3), "dimensions": {k:round(v,3) for k,v in evaluation.items()},
                "recommendations": recs[:5], "evaluations": self.eval_count, "interventions": self.intervention_count,
                "active_directives": len([d for d in self.directives[-10:] if d.status=="active"]),
                "total_directives": self.total_directives, "meta_confidence": round(self.meta_confidence, 3)}

    def get_directive_history(self, n=20):
        return [d.to_dict() for d in self.directives[-n:]]
