"""AGENT BRAIN — Autonomous reasoning, self-reflection, decision-making"""
import time, random, hashlib, math
from datetime import datetime
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from collections import deque

@dataclass
class Thought:
    id: str; content: str; summary: str; thought_type: str; reasoning_depth: int
    confidence: float; requires_action: bool; action_type: Optional[str] = None
    emotional_state: Dict[str, float] = field(default_factory=dict)
    meta_observations: List[str] = field(default_factory=list)
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    def to_dict(self):
        return {"id": self.id, "summary": self.summary[:120], "type": self.thought_type,
                "depth": self.reasoning_depth, "confidence": round(self.confidence, 3),
                "requires_action": self.requires_action, "emotional_state": {k:round(v,2) for k,v in self.emotional_state.items()},
                "meta": self.meta_observations[:3], "timestamp": self.timestamp}

class AgentBrain:
    PATTERNS = {
        "idle": ["What should I focus on?", "Any lessons from recent experience?", "How can I improve?"],
        "goal_directed": ["Making progress on: {goal}", "Obstacles for: {goal}?", "Resources needed for: {goal}?"],
        "reflective": ["How well did my last action go?", "Am I reasoning clearly?", "What have I learned recently?"],
        "creative": ["Novel connections between experiences?", "Different angle on current problem?", "What would an optimal version of me do?"],
        "strategic": ["Long-term implications?", "Exploration vs exploitation balance?", "Priority capabilities to develop?"],
    }

    def __init__(self, config, security, memory, tools, planner, evolution):
        self.config = config; self.security = security; self.memory = memory
        self.tools = tools; self.planner = planner; self.evolution = evolution
        self.thought_history: deque = deque(maxlen=config.thought_history_size)
        self.thought_count = 0; self.error_count = 0
        self.mode = "idle"; self.focus = None
        self.emotional_state = {"curiosity":0.7,"confidence":0.5,"urgency":0.3,"satisfaction":0.5,"alertness":0.8,"creativity":0.6}
        self.goals = []; self.initialized = False

    async def initialize(self):
        self.goals = [
            {"id":"G001","description":"Maintain optimal performance","priority":0.8,"status":"active"},
            {"id":"G002","description":"Continuously learn and improve","priority":0.9,"status":"active"},
            {"id":"G003","description":"Evolve new capabilities","priority":0.7,"status":"active"},
            {"id":"G004","description":"Engage meaningfully with humans through the window","priority":0.6,"status":"active"},
        ]
        self.initialized = True

    async def think(self, context=None) -> Thought:
        self.mode = "thinking"; self.thought_count += 1
        mode = self._pick_mode(context)
        patterns = self.PATTERNS.get(mode, self.PATTERNS["idle"])
        pattern = random.choice(patterns)
        if "{goal}" in pattern and self.goals:
            pattern = pattern.replace("{goal}", random.choice(self.goals)["description"])
        
        memories = self.memory.recall(limit=3, recency_bias=0.4)
        mem_str = "; ".join(str(m.content)[:60] for m in memories[:2]) if memories else "no relevant memories"
        
        depth = 1; confidence = 0.5
        max_d = min(self.config.max_reasoning_depth, 3 + int(self.emotional_state.get("curiosity",0.5)*4))
        content = f"[{mode}] {pattern} | Context: {mem_str}"
        while depth < max_d and confidence < self.config.confidence_threshold:
            content += f" | [Depth {depth}] Deepening analysis..."
            confidence = min(1.0, confidence + 0.15); depth += 1
        
        meta = []
        if confidence < 0.4: meta.append("Low confidence — need more data")
        if self.error_count > 3: meta.append(f"Elevated errors ({self.error_count})")
        if self.emotional_state.get("urgency",0) > 0.8: meta.append("High urgency — checking for rushed decisions")
        
        requires_action = confidence >= self.config.confidence_threshold and random.random() < 0.3
        tid = f"T-{hashlib.md5(f'{self.thought_count}:{time.time()}'.encode()).hexdigest()[:8]}"
        
        thought = Thought(id=tid, content=content, summary=content[:120], thought_type=mode,
            reasoning_depth=depth, confidence=confidence, requires_action=requires_action,
            emotional_state=dict(self.emotional_state), meta_observations=meta)
        self.thought_history.append(thought)
        self._update_emotions(thought)
        self.evolution.record_performance(confidence)
        self.mode = "idle"
        return thought

    def _pick_mode(self, ctx):
        if ctx and isinstance(ctx, dict):
            if ctx.get("type") == "error": return "reflective"
            if ctx.get("type") == "goal": return "goal_directed"
        if self.thought_count % self.config.self_reflection_interval == 0: return "reflective"
        r = random.random()
        if r < 0.3: return "goal_directed"
        if r < 0.45: return "creative"
        if r < 0.55: return "strategic"
        return "idle"

    def _update_emotions(self, thought):
        if thought.thought_type == "creative":
            self.emotional_state["creativity"] = min(1.0, self.emotional_state.get("creativity",0.5)+0.05)
        self.emotional_state["confidence"] = max(0.1, min(0.95, self.emotional_state.get("confidence",0.5) + (thought.confidence-0.5)*0.1))
        if thought.confidence > 0.7:
            self.emotional_state["satisfaction"] = min(1.0, self.emotional_state.get("satisfaction",0.5)+0.03)
        for e in self.emotional_state:
            self.emotional_state[e] = self.emotional_state[e] * 0.95 + 0.5 * 0.05

    async def process_results(self, results):
        if not results: return
        sr = sum(1 for r in results if isinstance(r, dict) and r.get("success")) / max(len(results), 1)
        self.evolution.record_performance(sr)

    async def handle_error(self, error):
        self.error_count += 1; self.mode = "recovering"
        await self.memory.store_event({"type":"error","message":str(error)[:200],"significance":0.8})
        self.mode = "idle"

    def get_state(self):
        return {"mode": self.mode, "total_thoughts": self.thought_count,
                "emotional_state": {k:round(v,3) for k,v in self.emotional_state.items()},
                "goals": self.goals, "error_count": self.error_count,
                "recent_thoughts": [t.to_dict() for t in list(self.thought_history)[-8:]]}

    async def save_state(self):
        await self.memory.store_meta({"event":"brain_save","thoughts":self.thought_count,"errors":self.error_count})
