"""
UNIVERSAL LLM CONNECTOR — Connect to ANY AI platform with a single interface.
Supports: OpenAI, Anthropic, Google, Mistral, Groq, Ollama, DeepSeek, xAI, Together, OpenRouter, and any OpenAI-compatible API.
"""
import json, time, traceback
from datetime import datetime
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field

@dataclass
class LLMResponse:
    text: str; provider: str; model: str; success: bool
    tokens_used: int = 0; latency: float = 0.0; error: Optional[str] = None
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    def to_dict(self):
        return {"text": self.text[:500], "provider": self.provider, "model": self.model,
                "success": self.success, "tokens": self.tokens_used, "latency": round(self.latency, 3),
                "error": self.error, "timestamp": self.timestamp}

class LLMConnector:
    """Universal LLM connector supporting multiple AI platforms."""
    
    PROVIDERS = {
        "openai": {"name": "OpenAI", "models": ["gpt-4o", "gpt-4o-mini", "gpt-4-turbo", "o1-preview", "o1-mini"]},
        "anthropic": {"name": "Anthropic", "models": ["claude-sonnet-4-20250514", "claude-haiku-4-5-20251001", "claude-opus-4-5-20250918"]},
        "google": {"name": "Google Gemini", "models": ["gemini-1.5-pro", "gemini-1.5-flash", "gemini-2.0-flash"]},
        "mistral": {"name": "Mistral AI", "models": ["mistral-large-latest", "mistral-medium", "mistral-small"]},
        "groq": {"name": "Groq", "models": ["llama-3.1-70b-versatile", "llama-3.1-8b-instant", "mixtral-8x7b-32768"]},
        "ollama": {"name": "Ollama (Local)", "models": ["llama3", "mistral", "codellama", "phi3"]},
        "deepseek": {"name": "DeepSeek", "models": ["deepseek-chat", "deepseek-coder"]},
        "xai": {"name": "xAI (Grok)", "models": ["grok-beta", "grok-2"]},
        "together": {"name": "Together AI", "models": ["meta-llama/Llama-3-70b-chat-hf", "mistralai/Mixtral-8x7B-Instruct-v0.1"]},
        "openrouter": {"name": "OpenRouter", "models": ["anthropic/claude-3.5-sonnet", "openai/gpt-4o", "google/gemini-pro"]},
        "custom": {"name": "Custom OpenAI-Compatible", "models": []},
    }

    def __init__(self, config):
        self.config = config
        self.history: List[LLMResponse] = []
        self.total_calls = 0; self.total_tokens = 0; self.total_errors = 0
        self.connected = False; self.current_provider = "none"

    async def initialize(self):
        if self.config.llm_api_key and self.config.llm_provider != "none":
            self.connected = True
            self.current_provider = self.config.llm_provider

    def configure(self, provider: str, api_key: str, model: str = "", base_url: str = ""):
        self.config.update_llm(provider, api_key, model, base_url)
        self.connected = bool(api_key) or provider == "ollama"
        self.current_provider = provider

    async def generate(self, prompt: str, system_prompt: str = "", temperature: float = None, max_tokens: int = None) -> LLMResponse:
        if not self.connected:
            return LLMResponse(text="[LLM not connected — using autonomous reasoning]",
                provider="none", model="none", success=False, error="No LLM configured")
        
        temp = temperature or self.config.llm_temperature
        tokens = max_tokens or self.config.llm_max_tokens
        provider = self.config.llm_provider
        model = self.config.llm_model
        
        start = time.time()
        self.total_calls += 1
        
        try:
            if provider in ("openai", "groq", "together", "openrouter", "deepseek", "xai", "custom"):
                result = await self._call_openai_compatible(prompt, system_prompt, temp, tokens, provider, model)
            elif provider == "anthropic":
                result = await self._call_anthropic(prompt, system_prompt, temp, tokens, model)
            elif provider == "google":
                result = await self._call_google(prompt, system_prompt, temp, tokens, model)
            elif provider == "mistral":
                result = await self._call_openai_compatible(prompt, system_prompt, temp, tokens, "mistral", model)
            elif provider == "ollama":
                result = await self._call_ollama(prompt, system_prompt, temp, tokens, model)
            else:
                result = LLMResponse(text="", provider=provider, model=model, success=False, error=f"Unknown provider: {provider}")
            
            result.latency = time.time() - start
            self.total_tokens += result.tokens_used
            if not result.success: self.total_errors += 1
            self.history.append(result)
            if len(self.history) > 100: self.history = self.history[-50:]
            return result
        except Exception as e:
            self.total_errors += 1
            r = LLMResponse(text="", provider=provider, model=model, success=False,
                error=str(e), latency=time.time()-start)
            self.history.append(r)
            return r

    async def _call_openai_compatible(self, prompt, system, temp, tokens, provider, model):
        import openai
        base_urls = {
            "openai": None, "groq": "https://api.groq.com/openai/v1",
            "together": "https://api.together.xyz/v1",
            "openrouter": "https://openrouter.ai/api/v1",
            "deepseek": "https://api.deepseek.com/v1",
            "xai": "https://api.x.ai/v1",
            "mistral": "https://api.mistral.ai/v1",
            "custom": self.config.llm_base_url or None,
        }
        client = openai.OpenAI(api_key=self.config.llm_api_key, base_url=base_urls.get(provider))
        msgs = []
        if system: msgs.append({"role": "system", "content": system})
        msgs.append({"role": "user", "content": prompt})
        resp = client.chat.completions.create(model=model, messages=msgs, temperature=temp, max_tokens=tokens)
        text = resp.choices[0].message.content or ""
        used = resp.usage.total_tokens if resp.usage else 0
        return LLMResponse(text=text, provider=provider, model=model, success=True, tokens_used=used)

    async def _call_anthropic(self, prompt, system, temp, tokens, model):
        import anthropic
        client = anthropic.Anthropic(api_key=self.config.llm_api_key)
        kw = {"model": model, "max_tokens": tokens, "temperature": temp,
              "messages": [{"role": "user", "content": prompt}]}
        if system: kw["system"] = system
        resp = client.messages.create(**kw)
        text = resp.content[0].text if resp.content else ""
        used = (resp.usage.input_tokens + resp.usage.output_tokens) if resp.usage else 0
        return LLMResponse(text=text, provider="anthropic", model=model, success=True, tokens_used=used)

    async def _call_google(self, prompt, system, temp, tokens, model):
        import google.generativeai as genai
        genai.configure(api_key=self.config.llm_api_key)
        m = genai.GenerativeModel(model)
        full = f"{system}\n\n{prompt}" if system else prompt
        resp = m.generate_content(full, generation_config={"temperature": temp, "max_output_tokens": tokens})
        return LLMResponse(text=resp.text, provider="google", model=model, success=True)

    async def _call_ollama(self, prompt, system, temp, tokens, model):
        import requests
        url = self.config.llm_base_url or "http://localhost:11434"
        msgs = []
        if system: msgs.append({"role": "system", "content": system})
        msgs.append({"role": "user", "content": prompt})
        resp = requests.post(f"{url}/api/chat", json={"model": model, "messages": msgs,
            "options": {"temperature": temp}, "stream": False}, timeout=60)
        data = resp.json()
        return LLMResponse(text=data.get("message",{}).get("content",""), provider="ollama", model=model, success=True)

    def get_stats(self):
        return {"connected": self.connected, "provider": self.current_provider,
                "model": self.config.llm_model, "total_calls": self.total_calls,
                "total_tokens": self.total_tokens, "total_errors": self.total_errors,
                "success_rate": round((self.total_calls-self.total_errors)/max(self.total_calls,1), 3),
                "available_providers": list(self.PROVIDERS.keys())}

    def get_providers_info(self):
        return self.PROVIDERS
