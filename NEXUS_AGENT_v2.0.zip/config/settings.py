"""Nexus Agent v2.0 — Configuration"""
import os, json
from dataclasses import dataclass, field
from pathlib import Path

@dataclass
class NexusConfig:
    agent_name: str = "NEXUS"
    agent_version: str = "2.0.0"
    base_dir: str = field(default_factory=lambda: os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    
    # Web Server
    host: str = "0.0.0.0"
    port: int = 5000
    debug: bool = False
    secret_key: str = "nexus-agent-secret-key-change-in-production"
    
    # LLM Configuration
    llm_provider: str = "none"  # openai, anthropic, google, mistral, groq, ollama, none
    llm_api_key: str = ""
    llm_model: str = ""
    llm_base_url: str = ""  # For custom endpoints
    llm_temperature: float = 0.7
    llm_max_tokens: int = 2048
    
    # Autonomous Cycle
    base_cycle_interval: float = 3.0
    min_cycle_interval: float = 0.5
    error_recovery_interval: float = 5.0
    
    # Brain Parameters
    max_reasoning_depth: int = 7
    creativity_factor: float = 0.7
    confidence_threshold: float = 0.6
    self_reflection_interval: int = 5
    thought_history_size: int = 200
    
    # Memory
    short_term_capacity: int = 50
    long_term_capacity: int = 10000
    memory_consolidation_interval: int = 20
    forgetting_threshold: float = 0.1
    memory_importance_decay: float = 0.995
    
    # Planning
    max_plan_steps: int = 20
    plan_timeout: float = 30.0
    replanning_threshold: float = 0.3
    
    # Evolution
    evolution_check_interval: int = 10
    mutation_rate: float = 0.15
    fitness_window: int = 50
    
    # Meta-AI
    meta_evaluation_interval: int = 3
    meta_intervention_threshold: float = 0.4
    meta_optimization_aggression: float = 0.5
    
    # Security
    human_view_rate_limit: int = 120
    audit_log_enabled: bool = True
    
    # Request Arbiter
    request_auto_approve_threshold: float = 0.8
    request_auto_deny_threshold: float = 0.2
    request_consideration_time: float = 2.0
    
    def get_path(self, subdir: str) -> Path:
        return Path(self.base_dir) / subdir
    
    def to_dict(self):
        d = {}
        for k, v in self.__dict__.items():
            if not k.startswith('_') and k != 'llm_api_key':
                d[k] = str(v) if isinstance(v, Path) else v
        return d
    
    def update_llm(self, provider: str, api_key: str, model: str = "", base_url: str = ""):
        self.llm_provider = provider
        self.llm_api_key = api_key
        self.llm_model = model or self._default_model(provider)
        self.llm_base_url = base_url
    
    def _default_model(self, provider: str) -> str:
        return {
            "openai": "gpt-4o",
            "anthropic": "claude-sonnet-4-20250514",
            "google": "gemini-1.5-pro",
            "mistral": "mistral-large-latest",
            "groq": "llama-3.1-70b-versatile",
            "ollama": "llama3",
            "deepseek": "deepseek-chat",
            "xai": "grok-beta",
            "together": "meta-llama/Llama-3-70b-chat-hf",
            "openrouter": "anthropic/claude-3.5-sonnet",
        }.get(provider, "")
